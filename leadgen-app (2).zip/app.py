from flask import Flask, render_template, request, redirect
from utils.crm_google_sheets import add_lead_to_sheet

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/submit', methods=['POST'])
def submit():
    lead = {
        "name": request.form['name'],
        "email": request.form['email'],
        "phone": request.form['phone'],
        "company": request.form['company'],
        "interest": request.form['interest']
    }
    add_lead_to_sheet(lead)
    return redirect('/thankyou')

@app.route('/thankyou')
def thankyou():
    return render_template('thankyou.html')

if __name__ == '__main__':
    app.run(debug=True)
